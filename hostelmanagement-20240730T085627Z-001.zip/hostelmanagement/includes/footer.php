<footer class="footer text-center text-muted">
&copy; <?php echo date("Y"); ?> - Hostel Management System - Developed by <a href="https://codeastro.com">CodeAstro</a>
</footer>